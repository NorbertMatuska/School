from scapy.all import rdpcap
from binascii import hexlify
import ruamel.yaml
from ruamel.yaml.scalarstring import LiteralScalarString


def testing_file():
    file_path = "vzorky_pcap_na_analyzu/"
    file_name = "trace-27.pcap"
    full_file_path = file_path + file_name

    return full_file_path


def get_ether_type(packet):
    ether_types = []
    with open("protocols/ethertype.txt", "r") as file:
        for line in file:
            hex_value, name = line.strip().split()

            ether_types.append((hex_value, name))

    for i in range(len(ether_types)):
        if ether_types[i][0] == hexlify(packet[12:14]).decode().upper():
            ether_type = ether_types[i][1]
            return ether_type


def get_pid_type(packet):
    pid_types = []
    with open("protocols/pid.txt", "r") as file:
        for line in file:
            hex_value, name = line.strip().split()

            pid_types.append((hex_value, name))

    for x in range(len(pid_types)):
        if pid_types[x][0] == hexlify(packet[20:22]).decode().upper():
            pid_type = pid_types[x][1]
            return pid_type


def get_sap_type(packet):
    sap_types = []
    with open("protocols/sap.txt", "r") as file:
        for line in file:
            hex_value, name = line.strip().split()

            sap_types.append((hex_value, name))

    for i in range(len(sap_types)):
        if sap_types[i][0] == hexlify(packet[14:15]).decode().upper():
            sap_type = sap_types[i][1]
            return sap_type


def read_file():
    full_file_path = testing_file()
    packets = rdpcap(full_file_path)

    packet_bytes = []
    for packet in packets:
        packet_bytes.append(bytes(packet))

    return packet_bytes


def format_hexa_frame(hexa_frame):
    formatted_hexa_frame = ""
    for i in range(len(hexa_frame)):
        formatted_hexa_frame += hexa_frame[i]
        if (i + 1) % 32 == 0:
            formatted_hexa_frame += "\n"
        elif (i + 1) % 2 == 0:
            if (i + 1) != len(hexa_frame):
                formatted_hexa_frame += " "

    if not len(hexa_frame) % 32 == 0:
        formatted_hexa_frame += "\n"
    return formatted_hexa_frame


def uloha1():
    packet_bytes = read_file()
    yaml = ruamel.yaml.YAML()

    full_file_path = testing_file()
    file_parts = full_file_path.split("/")
    file_name = file_parts[-1]
    print("Testing file: " + file_name)

    packets_array = []

    for i in range(len(packet_bytes)):
        packet = packet_bytes[i]

        frame_len = len(packet)
        if (len(packet) + 4) < 64:
            frame_len_medium = 64
        else:
            frame_len_medium = len(packet) + 4
        src_mac = hexlify(packet[6:12]).decode().upper()
        dst_mac = hexlify(packet[0:6]).decode().upper()
        hexa_frame = hexlify(packet).decode().upper()

        formatted_hex_frame = format_hexa_frame(hexa_frame)

        src_mac = ":".join([src_mac[i:i+2] for i in range(0, 12, 2)])
        dst_mac = ":".join([dst_mac[i:i+2] for i in range(0, 12, 2)])

        ether_type = None
        sap_type = None
        pid_type = None

        num_dec = int(str(hexlify(packet[12:14]))[2: -1], 16)

        if num_dec > 1500:
            frame_type = "ETHERNET II"
            # ether_type = get_ether_type(packet)
        else:
            if hexlify(packet[14:16]).decode() == "aaaa":
                frame_type = "IEEE 802.3 LLC & SNAP"
                pid_type = get_pid_type(packet)
            elif hexlify(packet[14:16]).decode() == "ffff":
                frame_type = "IEEE 802.3 RAW"
            else:
                frame_type = "IEEE 802.3 LLC"
                sap_type = get_sap_type(packet)

        data = {
            "frame_number": i+1,
            "len_frame_pcap": frame_len,
            "len_frame_medium": frame_len_medium,
            "frame_type": frame_type,
            "src_mac": src_mac,
            "dst_mac": dst_mac,
            **({"ether_type": ether_type} if ether_type is not None else {}),
            **({"sap": sap_type} if sap_type is not None else {}),
            **({"pid": pid_type} if pid_type is not None else {}),
            "hexa_frame": LiteralScalarString(formatted_hex_frame),
        }
        packets_array.append(data)

    start_data = {
        "name": "PKS2023/24",
        "pcap_name": file_name,
    }
    with open("hexdump.yaml", "w") as file1:
        yaml.dump(start_data, file1)

    with open("hexdump.yaml", "a") as yaml_file:
        yaml.default_flow_style = False
        yaml.explicit_start = False
        yaml.dump({"packets": packets_array}, yaml_file)


if __name__ == "__main__":

    uloha1()
