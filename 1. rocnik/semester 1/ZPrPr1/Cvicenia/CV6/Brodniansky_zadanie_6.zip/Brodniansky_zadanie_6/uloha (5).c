#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996)
#include <stdio.h>
#include <string.h>


char alphabet[] = { 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z' };
int count[26] = { 0 };
int r = 1;
void riadok();

int main() {
	int check = 0;
	char temp[1024], C;
	FILE* fr;

	printf("Zadajte meno suboru, ktory by ste chceli preskumat: ");
	scanf_s("%s", temp, 1023);

	temp[strlen(temp) ] = '\0';
	if ((fr = fopen(temp, "r")) == NULL) {
		
		printf("subor sa nepodarilo otvorit\n");
		
	}
	else {
		for (int i = 0; i <= 25; i++) {
			if (i == 0) {
				printf(" ");
			}
			printf("  %c", alphabet[i]);
		}
		printf("\n");
		
		while ((C = fgetc(fr)) != EOF) {
			/*printf("%d", check);
			check++;*/
			if (C == '\n' || C == EOF) {
				riadok();
				printf("\n");
				r++;
				for (int l = 0; l <= 25; l++) {
					count[l] = 0;
				}
			}
			else {
				for (int k = 0; k <= 25; k++) {
					if (C == alphabet[k] || C == (alphabet[k] + 32)) {
						count[k] = count[k] + 1;
						break;
					}
				}
			}
		}
		riadok();
		return 0;
	}

}

void riadok() {
	printf("%d", r);
	for (int j = 0; j <= 25; j++) {
		if (count[j] < 10) {
			printf("  %d", count[j]);
		}
		else {
			printf(" %d", count[j]);
		}

	}

}