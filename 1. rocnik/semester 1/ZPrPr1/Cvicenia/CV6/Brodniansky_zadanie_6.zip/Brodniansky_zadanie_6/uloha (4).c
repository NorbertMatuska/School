#include <stdio.h>

int main()
{
    char* x;
    int size;
    scanf_s("%d", &size);
    size++;
    x = (char*)malloc((size) * sizeof(char));
    for (int i = 0; i < size; i++) {
        scanf_s("%c", x+i);
    }

    for (int p = size - 1; p >= 0; p--) {
        printf("%c, ", x[p]);
    }
    return 0;
}
